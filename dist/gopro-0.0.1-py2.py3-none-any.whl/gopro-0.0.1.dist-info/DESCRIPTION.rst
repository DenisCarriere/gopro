Copyright (c) 2014-2015 Denis Carriere

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Download-URL: https://github.com/DenisCarriere/gopro/tarball/master
Description: # GoPro - Python API
        
        At the moment all testings are conducted with the newest version of the GoPro Hero 4.
        
        ## Install
        
        Easy install with Github or PyPi (Soon)
        
        Installing the **latest version from GitHub**.
        
        ```bash
        $ git clone https://github.com/DenisCarriere/gopro.git
        $ cd gopro
        $ python setup.py install
        ```
        
        Installing the **tested version from PyPi**.
        
        ```bash
        $ sudo pip install gopro
        ```
        
        ## Quickstart
        
        Once the installation is complete you are ready to start! :)
        
        Launch your favorite `ipython` or standard `python`
        
        ```
        >>> import gopro
        >>> camera = gopro.camera()
        >>> camera.photo()
        ```
        
        ## Camera modes
        
        Makes it easy to cycle threw each available modes.
        
        ```python
        camera.mode('burst')
        camera.mode('photo')
        camera.mode('timelapse')
        camera.mode('video')
        ```
        
        ## Locate (Beep! Beep!)
        
        Can't find your device?? Call the locate function and it will Beep endlessly until there is no more battery.
        
        To turn off the beeps, simply press the `mode` button on the device or use the `off` as a parameter.
        
        ```python
        camera.locate('on')
        camera.locate('off')
        ```
        
        ## Sleep
        
        The camera will turn itself off, the Wi-Fi will still be active.
        
        At the moment there is no working commands to turn the device back on.
        
        To reactivate the device, press the `mode` button.
        
        ```python
        camera.sleep()
        ```
        
        ## Delete Photos
        
        Might be useful to dump all those photos from your GoPro.
        
        **Warning** once you delete photos/videos you cannot retrieve them back.
        
        The `erase` function does the same as the delete all.
        
        ```python
        camera.erase()
        camera.delete_all()
        camera.delete_last()
        ```
        
        ## Debug
        
        Want to explore & troubleshoot the device a bit, you can retrieve the following properties from your device.
        
        ```
        camera.info
        camera.commands
        ```
        
        ## Contributors
        
        A big thanks to all the people who have helped contribute!
        
        To be a contributor, please message me with requests on [Twitter](https://twitter.com/DenisCarriere)/[Github issues](https://github.com/DenisCarriere/gopro/issues)
        
        - @[KonradIT](https://github.com/KonradIT)
        
        ## License
        
        The MIT License (MIT)
        
        Copyright (c) 2014-2015 Denis Carriere
Keywords: gopro camera hero black
Platform: UNKNOWN
Classifier: Development Status :: 5 - Production/Stable
Classifier: Intended Audience :: Developers
Classifier: Intended Audience :: Science/Research
Classifier: Natural Language :: English
Classifier: Operating System :: OS Independent
Classifier: Programming Language :: Python :: 2.6
Classifier: Programming Language :: Python :: 2.7
Classifier: Topic :: Internet
Classifier: Topic :: Internet :: WWW/HTTP
Classifier: Topic :: Scientific/Engineering :: GIS
Classifier: Topic :: Software Development :: Libraries :: Python Modules
